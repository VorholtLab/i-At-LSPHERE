Credits
=======

This application uses Open Source components. You can find the source code of their open source projects along with license information below. We acknowledge and are grateful to these developers for their contributions to open source.

All modifications performed by us are explicitly mentioned within the source code.

+-------------------+---------+---------------------------------------------------------------+
|   Project         | License |  URL                                                          |
+===================+=========+===============================================================+
| The COBRA Toolbox | GPL-3.0 | https://github.com/opencobra/cobratoolbox/                    |
+-------------------+---------+---------------------------------------------------------------+
